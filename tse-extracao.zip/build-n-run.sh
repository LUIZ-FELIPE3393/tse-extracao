tsc
node dist/src/app.js